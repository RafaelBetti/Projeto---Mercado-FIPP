package unoeste.fipp.mercadofipp.service;

import unoeste.fipp.mercadofipp.db.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import unoeste.fipp.mercadofipp.db.repository.UserRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User save(User user) {
        try {
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao salvar o usuário: " + e.getMessage());
        }
    }

    public List<User> findAll() {
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar usuários: " + e.getMessage());
        }
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public User update(Long id, User updatedUser) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setName(updatedUser.getName());
            existingUser.setPass(updatedUser.getPass());
            existingUser.setLevel(updatedUser.getLevel());
            return userRepository.save(existingUser);
        } else {
            throw new RuntimeException("Usuário com ID " + id + " não encontrado.");
        }
    }

    public void deleteById(Long id) {
        if (existsById(id)) {
            userRepository.deleteById(id);
        } else {
            throw new RuntimeException("Usuário com ID " + id + " não encontrado para exclusão.");
        }
    }

    public boolean existsById(Long id) {
        return userRepository.existsById(id);
    }

    // Método que utiliza o repositório para buscar usuários pelo nome e senha
    public List<User> findByNameAndPassword(String name, String password) {
        return userRepository.findByNameAndPass(name, password);
    }

    public boolean userExists(String name) {
        // Verifica se o nome de usuário existe no banco de dados
        return userRepository.existsByName(name);
    }

    // Função para excluir um usuário
    public boolean deleteUser(Long userId) {
        Optional<User> user = userRepository.findById(userId);
        if (user.isPresent()) {
            userRepository.delete(user.get());
            return true;
        }
        return false; // Caso o usuário não seja encontrado
    }
}



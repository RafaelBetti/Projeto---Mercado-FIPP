package unoeste.fipp.mercadofipp.service;

import unoeste.fipp.mercadofipp.db.entity.Pergunta;
import unoeste.fipp.mercadofipp.db.repository.PerguntaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PerguntaService {

    @Autowired
    private PerguntaRepository perguntaRepository;

    // Salva uma nova pergunta
    public Pergunta savePergunta(Pergunta pergunta) {
        return perguntaRepository.save(pergunta);
    }

    // Recupera todas as perguntas
    public List<Pergunta> getAllPerguntas() {
        return perguntaRepository.findAll();
    }

    // Recupera perguntas por id do anúncio
    public List<Pergunta> getPerguntasByAdId(Long adId) {
        return perguntaRepository.findByAdId(adId);
    }

    // Recupera uma pergunta por id
    public Optional<Pergunta> getPerguntaById(Long id) {
        return perguntaRepository.findById(id);
    }

    // Responde a uma pergunta
    public Pergunta respondPergunta(Long id, String resposta) {
        Optional<Pergunta> perguntaOptional = perguntaRepository.findById(id);
        if (perguntaOptional.isPresent()) {
            Pergunta pergunta = perguntaOptional.get();
            pergunta.setResp(resposta);
            return perguntaRepository.save(pergunta);
        }
        return null;
    }
}

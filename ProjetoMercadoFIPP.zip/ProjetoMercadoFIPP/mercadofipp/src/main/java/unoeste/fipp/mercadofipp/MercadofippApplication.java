package unoeste.fipp.mercadofipp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercadofippApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadofippApplication.class, args);
	}

}

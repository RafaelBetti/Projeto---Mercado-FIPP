package unoeste.fipp.mercadofipp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import unoeste.fipp.mercadofipp.db.entity.Category;
import unoeste.fipp.mercadofipp.db.repository.CategoryRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    // Salva uma categoria no banco de dados
    public Category save(Category category) {
        return categoryRepository.save(category);
    }

    // Retorna todas as categorias
    public List<Category> findAll() {
        return categoryRepository.findAll();
    }

    // Verifica se uma categoria com o nome fornecido já existe
    public boolean categoryExists(String name) {
        return categoryRepository.existsByName(name);
    }

    // Encontra uma categoria pelo ID
    public Optional<Category> findById(Long id) {
        return categoryRepository.findById(id);
    }

    // Deleta uma categoria pelo ID
    //public void deleteById(Long id) {
     //   categoryRepository.deleteById(id);
    //}

    // Função para excluir uma categoria
    public boolean deleteCategoria(Long categoriaId) {
        Optional<Category> categoria = categoryRepository.findById(categoriaId);
        if (categoria.isPresent()) {
            categoryRepository.delete(categoria.get());
            return true;
        }
        return false; // Caso a categoria não seja encontrada
    }
}



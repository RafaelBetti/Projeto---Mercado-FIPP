package unoeste.fipp.mercadofipp.restcontroller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import unoeste.fipp.mercadofipp.db.entity.User;
import unoeste.fipp.mercadofipp.service.UserService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;

import java.util.List;
@RestController
@CrossOrigin
@RequestMapping(value = "apis/user")
public class UserController {

    @Autowired
    HttpServletRequest request;

    @Autowired
    private UserService userService;

    // Endpoint para criar novo usuário
    @PostMapping(value = "/create")
    public ResponseEntity<Object> register(@RequestBody User newUser) {
        try {
            // Verifica se o nome de usuário já existe
            if (userService.userExists(newUser.getName())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
                        "error", "Usuário já existe. Escolha outro nome."
                ));
            }

            // Salva o novo usuário no banco
            User savedUser = userService.save(newUser);

            // Retorna resposta de sucesso com o ID, nome e nível do usuário
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "message", "Usuário cadastrado com sucesso!",
                    "userId", savedUser.getId(),
                    "name", savedUser.getName(), // Incluindo o nome do usuário na resposta
                    "level", savedUser.getLevel() // Incluindo o nível do usuário
            ));
        } catch (IllegalArgumentException e) {
            // Tratamento específico para dados inválidos
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "error", "Dados inválidos fornecidos. Verifique e tente novamente."
            ));
        } catch (Exception e) {
            // Log do erro para fins de depuração
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "error", "Erro ao cadastrar usuário. Tente novamente mais tarde."
            ));
        }
    }




    // Endpoint para listar usuários
    @GetMapping("/list")
    public ResponseEntity<Object> listUsers() {
        try {
            List<User> users = userService.findAll();

            if (users.isEmpty()) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Nenhum usuário encontrado.");
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response); // 204 No Content
            }

            return ResponseEntity.ok(users); // 200 OK
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("error", "Erro ao listar usuários: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response); // 500 Internal Server Error
        }
    }

    //Endpoint de Login
    @PostMapping("/login")
    public ResponseEntity<Object> loginUser(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();

        try {
            // Chama o método do serviço
            List<User> users = userService.findByNameAndPassword(user.getName(), user.getPass());

            if (users.isEmpty()) {
                response.put("status", "error");
                response.put("message", "Nome de usuário ou senha incorretos.");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response); // 401 Unauthorized
            } else if (users.size() > 1) {
                response.put("status", "error");
                response.put("message", "Erro: Mais de um usuário encontrado com as mesmas credenciais.");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(response); // 409 Conflict
            }

            //User user = users.get(0);
            response.put("status", "ok");
            response.put("message", "Login realizado com sucesso!");
            response.put("userId", user.getId());
            response.put("userName", user.getName());

            return ResponseEntity.ok(response); // 200 OK

        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "Erro ao realizar login: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response); // 500 Internal Server Error
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        boolean isRemoved = userService.deleteUser(id);
        if (!isRemoved) {
            return ResponseEntity.status(404).body("Usuário não encontrado.");
        }
        return ResponseEntity.status(200).body("Usuário excluído com sucesso.");
    }

}
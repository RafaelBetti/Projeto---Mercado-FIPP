package unoeste.fipp.mercadofipp.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import unoeste.fipp.mercadofipp.db.entity.Category;
import unoeste.fipp.mercadofipp.service.CategoryService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping(value = "apis/category")
public class CategoryController {

    @Autowired
    CategoryService categoryService;

    // Endpoint para criar uma nova categoria
    @PostMapping("/create")
    public ResponseEntity<Object> createCategory(@RequestBody Category newCategory) {
        try {
            // Verifica se o nome da categoria já existe
            if (categoryService.categoryExists(newCategory.getName())) {
                return ResponseEntity.status(409).body(Map.of(
                        "error", "Categoria já existe. Escolha outro nome."
                ));
            }

            // Salva a nova categoria no banco
            Category savedCategory = categoryService.save(newCategory);

            // Retorna resposta de sucesso com detalhes da categoria
            return ResponseEntity.ok(Map.of(
                    "message", "Categoria criada com sucesso!",
                    "categoryId", savedCategory.getId(),
                    "name", savedCategory.getName()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of(
                    "error", "Erro ao criar categoria. Tente novamente mais tarde."
            ));
        }
    }


    // Endpoint para listar todas as categorias
    @GetMapping("/list")
    public ResponseEntity<List<Category>> listCategories() {
        try {
            List<Category> categories = categoryService.findAll();
            return ResponseEntity.ok(categories); // Retorna 200 OK com a lista de categorias
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Retorna 500 em caso de erro
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteCategoria(@PathVariable Long id) {
        boolean isRemoved = categoryService.deleteCategoria(id);
        if (!isRemoved) {
            return ResponseEntity.status(404).body("Categoria não encontrada.");
        }
        return ResponseEntity.status(200).body("Categoria excluída com sucesso.");
    }
}


package unoeste.fipp.mercadofipp.db.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import unoeste.fipp.mercadofipp.db.entity.Pergunta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import unoeste.fipp.mercadofipp.db.entity.User;

import java.util.List;

@Repository
public interface PerguntaRepository extends JpaRepository<Pergunta, Long> {

    // Consulta com filtro utilizando SQL nativo
    @Query(value = "SELECT * FROM user WHERE LOWER(per_id) LIKE %:filter% OR LOWER(per_text) LIKE %:filter%", nativeQuery = true)
    List<User> findWithFilter(@Param("filter") String filter);

    // Método para buscar perguntas de um anúncio específico
    List<Pergunta> findByAdId(Long adId);
}

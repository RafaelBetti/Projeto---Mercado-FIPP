package unoeste.fipp.mercadofipp.restcontroller;

import unoeste.fipp.mercadofipp.db.entity.Pergunta;
import unoeste.fipp.mercadofipp.service.PerguntaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/apis/pergunta")
public class PerguntaController {

    @Autowired
    private PerguntaService perguntaService;

    // Endpoint para cadastrar uma nova pergunta
    @PostMapping("/create")
    public ResponseEntity<Object> createPergunta(@RequestBody Pergunta pergunta) {
        try {
            Pergunta savedPergunta = perguntaService.savePergunta(pergunta);
            return ResponseEntity.status(201).body(savedPergunta);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Erro ao cadastrar pergunta.");
        }
    }

    // Endpoint para listar todas as perguntas
    @GetMapping("/list")
    public ResponseEntity<List<Pergunta>> getAllPerguntas() {
        List<Pergunta> perguntas = perguntaService.getAllPerguntas();
        if (perguntas.isEmpty()) {
            return ResponseEntity.status(404).body(null); // Retorna 404 caso não haja perguntas
        }
        return ResponseEntity.ok(perguntas);
    }

    // Endpoint para listar perguntas por ID do anúncio
    @GetMapping("/by-ad/{adId}")
    public ResponseEntity<List<Pergunta>> getPerguntasByAdId(@PathVariable Long adId) {
        List<Pergunta> perguntas = perguntaService.getPerguntasByAdId(adId);
        if (perguntas.isEmpty()) {
            return ResponseEntity.status(404).body(null); // Retorna 404 se não houver perguntas para o anúncio
        }
        return ResponseEntity.ok(perguntas);
    }

    // Endpoint para responder a uma pergunta
    @PutMapping("/responder/{id}")
    public ResponseEntity<Object> respondPergunta(@PathVariable Long id, @RequestBody String resposta) {
        Pergunta perguntaRespondida = perguntaService.respondPergunta(id, resposta);
        if (perguntaRespondida != null) {
            return ResponseEntity.ok(perguntaRespondida);
        }
        return ResponseEntity.status(404).body("Pergunta não encontrada.");
    }

    // Endpoint para visualizar uma pergunta específica pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<Object> getPerguntaById(@PathVariable Long id) {
        Optional<Pergunta> pergunta = perguntaService.getPerguntaById(id);
        if (pergunta.isPresent()) {
            return ResponseEntity.ok(pergunta.get());
        }
        // Caso a pergunta não seja encontrada
        return ResponseEntity.status(404).body(Map.of("error", "Pergunta não encontrada."));
    }
}

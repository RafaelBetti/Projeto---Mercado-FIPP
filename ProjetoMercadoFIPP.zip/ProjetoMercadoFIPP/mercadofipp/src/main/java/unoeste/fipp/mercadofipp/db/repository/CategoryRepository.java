package unoeste.fipp.mercadofipp.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import unoeste.fipp.mercadofipp.db.entity.Ad;
import unoeste.fipp.mercadofipp.db.entity.Category;

import java.util.List;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    // Consulta personalizada para buscar categorias com base em um filtro (nome ou ID)
    @Query(value = "SELECT * FROM category WHERE lower(cat_name) LIKE %:filter% OR lower(cat_id) LIKE %:filter%", nativeQuery = true)
    List<Category> findWithFilter(@Param("filter") String filter);
    boolean existsByName(String name); // Verifica a existência pelo nome

}


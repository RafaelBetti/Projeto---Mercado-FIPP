package unoeste.fipp.mercadofipp.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import unoeste.fipp.mercadofipp.db.entity.User;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Consulta com filtro utilizando SQL nativo
    @Query(value = "SELECT * FROM user u WHERE LOWER(usr_name) LIKE %:filter% OR LOWER(usr_pass) LIKE %:filter%", nativeQuery = true)
    List<User> findWithFilter(@Param("filter") String filter);

    // Busca por nome e senha (case-sensitive por padrão)
    List<User> findByNameAndPass(String name, String pass);

    // Verifica se já existe um usuário com o nome fornecido
    boolean existsByName(String name);

    // Consulta adicional para encontrar usuários por nível (opcional)
    @Query("SELECT u FROM User u WHERE u.level = :level")
    List<User> findByLevel(@Param("level") String level);
}

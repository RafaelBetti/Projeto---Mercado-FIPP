package unoeste.fipp.mercadofipp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadofippApplicationTests {

	@Test
	void contextLoads() {
	}

}

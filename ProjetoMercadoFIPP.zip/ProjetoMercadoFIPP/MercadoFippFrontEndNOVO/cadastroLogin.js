async function cadastroUsuario(event) 
{
    event.preventDefault(); 

    
    const name = document.getElementById('name').value;
    const pass = document.getElementById('pass').value;
    const level = document.getElementById('level').value;

    
    const cadastroData = {
        name: name,
        pass: pass,
        level: level
    };
    console.log("Dados enviados:", cadastroData);

    try {
        const response = await fetch('http://localhost:8080/apis/user/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(cadastroData),
            mode: 'no-cors' 
        });

        //response.status === "ok"
        if (response.created || response.statusCode === 201) {
            localStorage.setItem('name', result.name);
            console.log("Resposta bem-sucedida");
            const result = await response.json();
            alert(`Usuário cadastrado com sucesso: ${result.name}`);
            window.location.href = "/index.html"; 
        } else {
            alert("Erro: " + response.message); 
        }
    } catch (error) {
        console.error('Erro na solicitação:', error);
    }
}


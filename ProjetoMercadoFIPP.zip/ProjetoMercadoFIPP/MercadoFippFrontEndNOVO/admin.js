// Função para criar uma nova categoria
async function createCategory(event) {
    event.preventDefault();
    const categoria = document.getElementById('categoriaAnuncio').value;
    const descricao = document.getElementById('descricaoAnuncio').value;

    const categoryData = {
        categoria: categoria,
        descricao: descricao
    };

    try {
        const response = await fetch('http://localhost:8080/apis/category/create', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify(categoryData),
            mode: 'no-cors'
        });

        if (response.ok) {
            alert('Categoria cadastrada com sucesso!');
            loadCategories(); // Recarregar lista de categorias
        } else {
            const error = await response.json();
            alert(`Erro: ${error.message}`);
        }
    } catch (error) {
        console.error('Erro ao criar categoria:', error);
        alert('Erro de conexão com o servidor.');
    }
}

// Função para carregar todas as categorias
async function loadCategories(event) {
    event.preventDefault();
    try {
        const response = await fetch('http://localhost:8080/apis/category/list', {
            method: 'GET', // Método HTTP
            headers: {
                'Content-Type': 'application/json', // Tipo de conteúdo
            },
            mode: 'cors' // Ativa o CORS
        });

        if (!response.ok) {
            throw new Error(`Erro: ${response.statusText}`);
        }

        const categories = await response.json();
        const categoryList = document.getElementById('categoryList');
        categoryList.innerHTML = ''; // Limpar lista antes de adicionar

        categories.forEach(category => {
            const categoryItem = document.createElement('li');
            categoryItem.classList.add('list-group-item');
            categoryItem.innerHTML = `
                ${category.name} - ${category.description}
                <button class="btn btn-danger btn-sm float-right" onclick="deleteCategory(${category.id})">Excluir</button>
            `;
            categoryList.appendChild(categoryItem);
        });
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}


// Função para excluir uma categoria
async function deleteCategory(categoryId,event) {
    event.preventDefault();
    const confirmDelete = confirm("Você tem certeza que deseja excluir esta categoria?");
    if (!confirmDelete) return;

    try {
        const response = await fetch(`http://localhost:8080/apis/category/delete/${categoryId}`, {
            method: 'DELETE',
            mode: 'no-cors'
        });

        if (response.ok) {
            alert('Categoria excluída com sucesso!');
            loadCategories(); // Recarregar lista de categorias
        } else {
            const error = await response.json();
            alert(`Erro: ${error.message}`);
        }
    } catch (error) {
        console.error('Erro ao excluir categoria:', error);
        alert('Erro de conexão com o servidor.');
    }
}

// Função para excluir um anúncio
async function deleteAd(event) {
    event.preventDefault();
    const adId = document.getElementById('adId').value;

    if (!adId) {
        alert('Por favor, forneça o ID do anúncio.');
        return;
    }

    const confirmDelete = confirm("Você tem certeza que deseja excluir este anúncio?");
    if (!confirmDelete) return;

    try {
        const response = await fetch(`http://localhost:8080/apis/ad/delete/${adId}`, {
            method: 'DELETE',
            mode: 'no-cors'
        });

        if (response.ok) {
            alert('Anúncio excluído com sucesso!');
        } else {
            const error = await response.json();
            alert(`Erro: ${error.message}`);
        }
    } catch (error) {
        console.error('Erro ao excluir anúncio:', error);
        alert('Erro de conexão com o servidor.');
    }
}

// Função para excluir um usuário
async function deleteUser(event) {
    event.preventDefault();
    const userId = document.getElementById('userId').value;

    if (!userId) {
        alert('Por favor, forneça o ID do usuário.');
        return;
    }

    const confirmDelete = confirm("Você tem certeza que deseja excluir este usuário?");
    if (!confirmDelete) return;

    try {
        const response = await fetch(`http://localhost:8080/apis/user/delete/${userId}`, {
            method: 'DELETE',
            mode: 'no-cors'
        });

        if (response.ok) {
            alert('Usuário excluído com sucesso!');
        } else {
            const error = await response.json();
            alert(`Erro: ${error.message}`);
        }
    } catch (error) {
        console.error('Erro ao excluir usuário:', error);
        alert('Erro de conexão com o servidor.');
    }
}

// Carregar categorias ao carregar a página
window.onload = loadCategories;

// Função para enviar pergunta ao backend
async function enviarPergunta(event) {
    event.preventDefault();
    const perguntaText = document.getElementById('perguntaInput').value;
    const anuncioId = document.getElementById('anuncioIdInput').value;

    const perguntaData = {
        text: perguntaText,
        ad: { id: anuncioId },
    };

    try {
        const response = await fetch('http://localhost:8080/apis/pergunta/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(perguntaData),
            mode: 'no-cors'
        });

        if (response.ok) {
            const result = await response.json();
            alert(`Pergunta enviada com sucesso: ${result.text}`);
            // Atualiza a lista de perguntas após o envio
            carregarPerguntas();
        } else {
            const error = await response.json();
            alert(`Erro: ${error.error || "Erro desconhecido."}`);
        }
    } catch (error) {
        console.error("Erro de conexão:", error);
        alert("Erro de conexão com o servidor.");
    }
}

// Função para carregar as perguntas
async function carregarPerguntas(event) {
    event.preventDefault();
    const anuncioId = document.getElementById('anuncioIdInput').value;

    try {
        const response = await fetch(`http://localhost:8080/apis/pergunta/by-ad/${anuncioId}`);
        if (response.ok) {
            const perguntas = await response.json();
            const perguntasList = document.getElementById('perguntasList');
            perguntasList.innerHTML = ''; // Limpar lista antes de adicionar

            perguntas.forEach(pergunta => {
                const perguntaItem = document.createElement('div');
                perguntaItem.classList.add('list-group-item');
                perguntaItem.innerHTML = `
                    <strong>Pergunta:</strong> ${pergunta.text} <br>
                    <strong>Resposta:</strong> ${pergunta.resp || 'Sem resposta ainda'}
                `;
                perguntasList.appendChild(perguntaItem);
            });
        } else {
            alert("Nenhuma pergunta encontrada para este anúncio.");
        }
    } catch (error) {
        console.error("Erro de conexão:", error);
        alert("Erro ao carregar perguntas.");
    }
}

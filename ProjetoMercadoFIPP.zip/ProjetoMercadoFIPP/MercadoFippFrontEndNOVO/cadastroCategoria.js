async function cadastrarAnuncio(event) 
{
    event.preventDefault();

    const titulo = document.getElementById('tituloAnuncio').value;  
    const descricao = document.getElementById('descricaoAnuncio').value;  
    const categoria = document.getElementById('categoriaAnuncio').value;  
    const data = document.getElementById('data').value;  
    const valor = document.getElementById('precoAnuncio').value;  
    const fotos = document.getElementById('fotos').files;  

    const categorias = {
        'informática': 1,
        'livros': 2,
        'celulares': 3,
        'acessorios': 4
    };

    const catId = categorias[categoria];

    if (!catId) {
        alert('Categoria não encontrada!');
        return;
    }

    const anuncioData = {
        titulo: titulo,
        descricao: descricao,
        categoria: catId,  
        data: data,
        valor: valor,
        fotos: [] 
    };

    for (let i = 0; i < fotos.length; i++) {
        anuncioData.fotos.push(fotos[i]);
    }

    console.log(anuncioData);

    const formData = new FormData();
    formData.append("titulo", titulo);
    formData.append("descricao", descricao);
    formData.append("categoria", catId); 
    formData.append("data", data);
    formData.append("valor", valor);
    for (let i = 0; i < fotos.length; i++) {
        formData.append("fotos", fotos[i]);
    }

    try {
        const response = await fetch('http://localhost:8080/apis/category/create', {
            method: 'POST',
            body: formData,  
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(anuncioData),
            mode: 'no-cors'
        });

        //response.ok
        if (response.statusCode === 201) { 
            const result = await response.json();
            alert(`Anúncio cadastrado com sucesso: ${result.titulo}`);
        } else {
            alert("Erro: " + response.message); // Exibe a mensagem de erro
        }
    } catch (error) {
        console.error('Erro na solicitação:', error);
    }
}


async function login(event)
{
        event.preventDefault();
 
        const name = document.getElementById('name').value;
        const pass = document.getElementById('pass').value;

        const loginData = {
            name: name,
            pass: pass,
        };
        console.log(loginData);

        try {
            const response = await fetch('http://localhost:8080/apis/user/login', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(loginData),
                mode: 'no-cors'
            });

            

            //response.created || response.statusCode === 200
            if (response.status === "ok") {
                localStorage.setItem('name', result.name);
                const result = await response.json();
                alert(`Bem-vindo, ${result.name}!`);
                window.location.href = "/index.html"; 
            } else {
                alert("Erro: " + response.message); 
            }
        } catch (error) {
            console.error('Erro na solicitação:', error);
        }
}
